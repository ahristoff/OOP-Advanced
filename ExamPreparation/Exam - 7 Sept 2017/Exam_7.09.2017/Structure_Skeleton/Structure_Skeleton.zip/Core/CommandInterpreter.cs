﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


public class CommandInterpreter : ICommandInterpreter
{
    //    private IHarvesterController harvesterController;//
    //    private IProviderController providerController;//
    public CommandInterpreter(IHarvesterController harvesterController, IProviderController providerController)
    {
        this.HarvesterController = harvesterController;
        this.ProviderController = providerController;

        //this.harvesterController = harvesterController;
        //this.providerController = providerController;
    }

    public IHarvesterController HarvesterController { get; private set; }

    public IProviderController ProviderController { get; private set; }



    public string ProcessCommand(IList<string> args)
    {
        ICommand command = this.CreateCommand(args);

        string result = command.Execute();
        return result;
    }

    public ICommand CreateCommand(IList<string> args)//beshe privat i go njamashe v interface
    {

        //string commandName = args[0];                           // ednakvi ctori
        //Assembly type = Assembly.GetCallingAssembly();

        //var command = type.GetTypes().FirstOrDefault(c => c.Name == commandName + "Command");

        //var instance = (ICommand)Activator.CreateInstance(command, args.Skip(1).ToList(), this.HarvesterController, this.ProviderController);
        //return instance;

        //-------------------------------------------------------------------------------------------------------------

        string commandName = args[0];                           // razlichni ctori

        Assembly commandType = Assembly.GetCallingAssembly();
        var com = commandType.GetTypes().FirstOrDefault(c => c.Name == commandName + "Command");

        if (commandType == null)
        {
            throw new ArgumentException(string.Format(Constants.CommandNotFound, commandName));
        }

        if (!typeof(ICommand).IsAssignableFrom(com))  // vinagi s !
        {
            throw new InvalidOperationException(string.Format(Constants.InvalidCommand, commandName));
        }

        ConstructorInfo ctor = com.GetConstructors().First();
        ParameterInfo[] parameterInfos = ctor.GetParameters();

        object[] parameters = new object[parameterInfos.Length];

        for (int i = 0; i < parameterInfos.Length; i++)
        {
            Type paramType = parameterInfos[i].ParameterType;

            if (paramType == typeof(IList<string>))
            {
                parameters[i] = args.Skip(1).ToList();//propuskame imeto na comandata
            }
            //else                               //ako e IHarvesterController ili IProviderController
            //{
            //    PropertyInfo paramInfo = this.GetType().GetProperties()
            //        .FirstOrDefault(p => p.PropertyType == paramType);

            //    parameters[i] = paramInfo.GetValue(this);
            //}
            else if (paramType == typeof(IHarvesterController))
            {
                parameters[i] = this.HarvesterController;
            }

            else if (paramType == typeof(IProviderController))
            {
                parameters[i] = this.ProviderController;
            }
        }

        ICommand instance = (ICommand)Activator.CreateInstance(com, parameters);

        return instance;
    }
}

