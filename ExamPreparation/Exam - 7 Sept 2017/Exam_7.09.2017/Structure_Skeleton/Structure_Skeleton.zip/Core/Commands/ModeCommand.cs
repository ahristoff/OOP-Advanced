﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class ModeCommand : Command
{
    private IHarvesterController harvesterController;
    //private IProviderController providerController; // da se mahne

    public ModeCommand(IList<string> args, IHarvesterController harvesterController/*, IProviderController providerController*/) : base(args)
        //IProviderController providerController da se mahne
    {
        this.harvesterController = harvesterController;
        //this.providerController = providerController; //da se mahne
    }

    public override string Execute()
    {
        string mode = this.Arguments[0];

        string res = this.harvesterController.ChangeMode(mode);

        return res;
    }
}
