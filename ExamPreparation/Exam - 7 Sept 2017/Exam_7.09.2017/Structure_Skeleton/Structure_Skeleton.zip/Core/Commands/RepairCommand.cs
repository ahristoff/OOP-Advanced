﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class RepairCommand : Command
{
    //private IHarvesterController harvesterController;   // da se mahne 
    private IProviderController providerController; 

    public RepairCommand(IList<string> args/*, IHarvesterController harvesterController*/, IProviderController providerController) : base(args)
     //IHarvesterController harvesterController da se mahne
    {
        //this.harvesterController = harvesterController;   //da se mahne
        this.providerController = providerController; 
    }

    public override string Execute()
    {
        var val = double.Parse(this.Arguments[0]);
       var res =  this.providerController.Repair(val);

        return res;
    }
}

