﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class HarvesterController : IHarvesterController
{
    private string mode;
    private IEnergyRepository energyRepository;
    private IList<IHarvester> harvesters;
    private IHarvesterFactory harvesterFactory;

    

    public HarvesterController(IEnergyRepository energyRepository, IHarvesterFactory harvesterFactory)
    {
        this.energyRepository = energyRepository;
        this.harvesterFactory = harvesterFactory;

        this.mode = Constants.DefaultMode;
        this.harvesters = new List<IHarvester>();
    }

    public double OreProduced { get; private set; }

    public IReadOnlyCollection<IEntity> Entities => (IReadOnlyCollection<IHarvester>)this.harvesters;//ednakvo kakto pri providerController

    public string ChangeMode(string mode)
    {
        
        this.mode = mode;
        List<IHarvester> reminder = new List<IHarvester>(); //spisak s neshtata, koito sa schupeni

        foreach (var x in this.harvesters)
        {
            try
            {
                x.Broke();
            }
            catch (Exception)
            {
                reminder.Add(x);
            }
        }

        foreach (var entity in reminder) //izvajdame schupenite neshta ot spisaka harvesters
        {
            this.harvesters.Remove(entity);
        }
        return string.Format(Constants.ModeChange, mode);
    }

    public string Produce()// Day ot DraftManager
    {
        double neededEnergy = 0;
        foreach (var harvester in this.harvesters)
        {
            if (this.mode == "Full")
            {
                neededEnergy += harvester.EnergyRequirement;
            }
            else if (this.mode == "Half")
            {
                neededEnergy += harvester.EnergyRequirement * 50 / 100;
            }
            else if (this.mode == "Energy")
            {
                neededEnergy += harvester.EnergyRequirement * 20 / 100;
            }
        }

        //check if we can mine
        double minedOres = 0;
        if (this.energyRepository.TakeEnergy(neededEnergy))//proverka dali shte ni stigne proizvedenata energia
        {
            //mine
           
            foreach (var harvester in this.harvesters)
            {
                minedOres += harvester.Produce();
            }
        }

        //take the mode in mind
        if (this.mode == "Energy")
        {
            minedOres = minedOres * 20 / 100;
        }
        else if (this.mode == "Half")
        {
            minedOres = minedOres * 50 / 100;
        }

        this.OreProduced += minedOres;
      
       return string.Format(Constants.OreOutputToday, minedOres);

        
    }

    public string Register(IList<string> args)
    {
        var harvester = this.harvesterFactory.GenerateHarvester(args);
        this.harvesters.Add(harvester);
        return string.Format(Constants.SuccessfullRegistration, harvester.GetType().Name);
    }
}

