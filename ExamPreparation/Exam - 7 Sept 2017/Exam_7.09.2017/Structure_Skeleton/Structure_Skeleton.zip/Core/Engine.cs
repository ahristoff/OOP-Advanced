﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Engine
{
    private ICommandInterpreter commandInterpreter;
    private IWriter writer;
    private IReader reader;

    public Engine(ICommandInterpreter commandInterpreter, IReader reader, IWriter writer)
    {
        this.commandInterpreter = commandInterpreter;
        this.reader = reader;
        this.writer = writer;
    }

    public void Run()
    {
        while (true)
        {

            List<string> inputArgs = reader.ReadLine().Split().ToList();

            var res = commandInterpreter.ProcessCommand(inputArgs);
            //var res = commandInterpreter.CreateCommand(inputArgs).Execute();

            writer.WriteLine(res);

            if (inputArgs[0] == "Shutdown")
            {
                break;
            }

        }
//--------------------------------------------------------------------------------------------------------------


            //var input = Console.ReadLine();
            //var data = input.Split().ToList();
            //var command = data[0];
            //switch (command)
            //{
            //    case "RegisterHarvester":
            //        var args = new List<string>(data.Skip(1).ToList());
            //        manager.RegisterHarvester(args);
            //        break;
            //    case "RegisterProvider":
            //        args = new List<string>(data.Skip(1).ToList());
            //        manager.RegisterProvider(args);
            //        break;
            //    case "Day":
            //        manager.Day();
            //        break;
            //    case "Mode":
            //        args = new List<string>(data.Skip(1).ToList());
            //        manager.Mode(args);
            //        break;
            //    case "Check":
            //        args = new List<string>(data.Skip(1).ToList());
            //        //Console.WriteLine(manager.Check(args));
            //        break;
            //    default:
            //        manager.ShutDown();
            //        Environment.Exit(0);
            //        break;
            //}
        //}
    }
}
