﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class EnergyRepository : IEnergyRepository
{

    public double EnergyStored { get; private set; }

    public void StoreEnergy(double energy)
    {
        this.EnergyStored += energy;
    }

    public bool TakeEnergy(double energyNeeded)// ako ne mi stiga tazi energija - false, ako da maham energijata - true
    {
        if (this.EnergyStored < energyNeeded)
        {
            return false;
        }
        this.EnergyStored -= energyNeeded;
        return true;
    }
}

